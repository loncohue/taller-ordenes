import { useState, useMemo } from 'react'
import { Toaster } from 'react-hot-toast'
import { signOut } from '../lib/supabase'
import { useAuth } from '../hooks/useAuth'
import { useOrders } from '../hooks/useOrders'
import { useNotifications } from '../hooks/useNotifications'
import NotificationsPanel from '../components/NotificationsPanel'

// ─── CONSTANTS ────────────────────────────────────────────────────────────────
const MECANICOS = ['Fernando', 'Pippo', 'Pompo', 'Cristian', 'Marcos']
const ASESORES = ['Santiago', 'Rafael', 'Roque']
const ESTADOS = { ESPERA: 'A la espera', PROCESO: 'En proceso', FINALIZADO: 'Finalizado' }
const ESTADO_COLOR = { 'A la espera': '#e8a838', 'En proceso': '#3b82f6', 'Finalizado': '#22c55e' }

// ─── HELPERS ─────────────────────────────────────────────────────────────────
const fmt = (iso) => {
  if (!iso) return '—'
  return new Date(iso).toLocaleString('es-AR', { hour12: false, day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' })
}
const isSameDay = (a, b) => {
  const da = new Date(a), db = new Date(b)
  return da.getFullYear() === db.getFullYear() && da.getMonth() === db.getMonth() && da.getDate() === db.getDate()
}
const startOf = (unit) => {
  const d = new Date()
  if (unit === 'day') { d.setHours(0, 0, 0, 0); return d }
  if (unit === 'week') { d.setDate(d.getDate() - d.getDay()); d.setHours(0, 0, 0, 0); return d }
  if (unit === 'month') { d.setDate(1); d.setHours(0, 0, 0, 0); return d }
  if (unit === 'year') { d.setMonth(0, 1); d.setHours(0, 0, 0, 0); return d }
  return d
}
const endOf = (unit) => {
  const d = new Date()
  if (unit === 'day') { d.setHours(23, 59, 59, 999); return d }
  if (unit === 'week') { d.setDate(d.getDate() + (6 - d.getDay())); d.setHours(23, 59, 59, 999); return d }
  if (unit === 'month') { d.setMonth(d.getMonth() + 1, 0); d.setHours(23, 59, 59, 999); return d }
  if (unit === 'year') { d.setMonth(11, 31); d.setHours(23, 59, 59, 999); return d }
  return d
}

// ─── STYLES ───────────────────────────────────────────────────────────────────
const inp = { background: '#0f1320', border: '1px solid #2d3448', borderRadius: '6px', color: '#e2e8f0', padding: '0.5rem 0.75rem', width: '100%', fontSize: '0.85rem', outline: 'none', boxSizing: 'border-box' }
const lab = { display: 'block', color: '#94a3b8', fontSize: '0.72rem', marginBottom: '4px', textTransform: 'uppercase', letterSpacing: '0.05em' }
const Field = ({ label, children }) => <div style={{ marginBottom: '0.9rem' }}><label style={lab}>{label}</label>{children}</div>

// ─── MODAL ────────────────────────────────────────────────────────────────────
function Modal({ title, onClose, children }) {
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '1rem' }}>
      <div style={{ background: '#1a1f2e', border: '1px solid #2d3448', borderRadius: '12px', width: '100%', maxWidth: '680px', maxHeight: '90vh', overflowY: 'auto', boxShadow: '0 25px 60px rgba(0,0,0,0.5)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '1.25rem 1.5rem', borderBottom: '1px solid #2d3448', position: 'sticky', top: 0, background: '#1a1f2e', zIndex: 1 }}>
          <h3 style={{ margin: 0, color: '#e2e8f0', fontSize: '1.1rem', fontWeight: 600 }}>{title}</h3>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: '#64748b', cursor: 'pointer', fontSize: '1.4rem', lineHeight: 1 }}>×</button>
        </div>
        <div style={{ padding: '1.5rem' }}>{children}</div>
      </div>
    </div>
  )
}

// ─── NEW ORDER FORM ───────────────────────────────────────────────────────────
function NuevaOrdenModal({ onClose, onSave }) {
  const [form, setForm] = useState({ orden: '', asesor: ASESORES[0], servicio: 'ninguno', adicionales: '', otros: '' })
  const s = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }))
  const save = async () => {
    if (!form.orden.trim()) return alert('Ingresá el número de orden')
    await onSave(form)
    onClose()
  }
  return (
    <Modal title="➕ Nueva Orden" onClose={onClose}>
      <Field label="N° de Orden"><input style={inp} value={form.orden} onChange={s('orden')} placeholder="Ej: 90800" /></Field>
      <Field label="Asesor"><select style={inp} value={form.asesor} onChange={s('asesor')}>{ASESORES.map(a => <option key={a}>{a}</option>)}</select></Field>
      <Field label="Tipo de Servicio">
        <select style={inp} value={form.servicio} onChange={s('servicio')}>
          <option value="ninguno">Sin servicio</option>
          <option value="servicio">Servicio</option>
        </select>
      </Field>
      <Field label="Adicionales al servicio"><input style={inp} value={form.adicionales} onChange={s('adicionales')} placeholder="Ej: Liq. frenos, bujias..." /></Field>
      <Field label="Otros (fuera del servicio)"><input style={inp} value={form.otros} onChange={s('otros')} placeholder="Ej: Cambio de optica..." /></Field>
      <button onClick={save} style={{ background: '#3b82f6', color: '#fff', border: 'none', borderRadius: '8px', padding: '0.75rem 2rem', cursor: 'pointer', fontWeight: 600, fontSize: '0.9rem', width: '100%' }}>Crear Orden</button>
    </Modal>
  )
}

// ─── EDIT ORDER MODAL ─────────────────────────────────────────────────────────
function EditarOrdenModal({ orden, onClose, onSave }) {
  const [form, setForm] = useState({ ...orden })
  const s = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value }))

  const toggleMecanico = (m) => {
    const cur = form.mecanicos || []
    const next = cur.includes(m) ? cur.filter(x => x !== m) : [...cur, m]
    let estado = form.estado
    if (next.length > 0 && form.estado === ESTADOS.ESPERA) estado = ESTADOS.PROCESO
    if (next.length === 0 && form.estado === ESTADOS.PROCESO) estado = ESTADOS.ESPERA
    setForm(f => ({ ...f, mecanicos: next, estado }))
  }

  const finalizar = () => {
    const fin = new Date().toISOString()
    const enDia = isSameDay(form.fecha, fin) && (new Date(fin) - new Date(form.fecha)) < 9 * 3600000
    setForm(f => ({ ...f, estado: ESTADOS.FINALIZADO, finalizado_fecha: fin, terminado_en_dia: enDia }))
  }

  const registrarRespuesta = () => setForm(f => ({ ...f, respuesta_fecha: new Date().toISOString() }))

  const save = async () => { await onSave(form); onClose() }

  const col = ESTADO_COLOR[form.estado]

  return (
    <Modal title={`Orden #${form.orden}`} onClose={onClose}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 1rem' }}>
        <Field label="Estado">
          <div style={{ background: col + '22', border: `1px solid ${col}`, borderRadius: '6px', padding: '0.45rem 0.75rem', color: col, fontWeight: 600, fontSize: '0.85rem' }}>{form.estado}</div>
        </Field>
        <Field label="Asesor">
          <select style={inp} value={form.asesor} onChange={s('asesor')}>{ASESORES.map(a => <option key={a}>{a}</option>)}</select>
        </Field>
      </div>

      <Field label="Mecánicos asignados">
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem' }}>
          {MECANICOS.map(m => (
            <button key={m} onClick={() => toggleMecanico(m)} style={{
              padding: '0.35rem 0.7rem', borderRadius: '6px', border: '1px solid',
              borderColor: (form.mecanicos || []).includes(m) ? '#3b82f6' : '#2d3448',
              background: (form.mecanicos || []).includes(m) ? '#1d4ed8' : '#0f1320',
              color: (form.mecanicos || []).includes(m) ? '#fff' : '#64748b',
              cursor: 'pointer', fontSize: '0.8rem'
            }}>{m}</button>
          ))}
        </div>
      </Field>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 1rem' }}>
        <Field label="Tipo de Servicio">
          <select style={inp} value={form.servicio} onChange={s('servicio')}>
            <option value="ninguno">Sin servicio</option>
            <option value="servicio">Servicio</option>
          </select>
        </Field>
        <div />
      </div>
      <Field label="Adicionales al servicio"><input style={inp} value={form.adicionales || ''} onChange={s('adicionales')} /></Field>
      <Field label="Otros (fuera del servicio)"><input style={inp} value={form.otros || ''} onChange={s('otros')} /></Field>

      {/* PRESUPUESTO */}
      <div style={{ background: '#0f1320', border: '1px solid #2d3448', borderRadius: '8px', padding: '1rem', marginBottom: '0.9rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: form.presupuesto ? '0.75rem' : 0 }}>
          <input type="checkbox" id="pres" checked={form.presupuesto || false} onChange={s('presupuesto')} />
          <label htmlFor="pres" style={{ color: '#e2e8f0', fontSize: '0.85rem', fontWeight: 600, cursor: 'pointer' }}>Hay Presupuesto</label>
        </div>
        {form.presupuesto && (<>
          <Field label="Tipo">
            <select style={inp} value={form.presupuesto_tipo || ''} onChange={s('presupuesto_tipo')}>
              <option value="">Seleccionar...</option>
              <option value="frenos">Frenos</option>
              <option value="bateria">Batería</option>
              <option value="frenos_bateria">Frenos + Batería</option>
              <option value="otros">Otros</option>
            </select>
          </Field>
          <Field label="Detalle">
            <input style={inp} value={form.presupuesto_detalle || ''} onChange={s('presupuesto_detalle')} placeholder="Descripción de trabajos..." />
          </Field>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 1rem' }}>
            <Field label="Respuesta del cliente">
              <select style={inp} value={form.respuesta_cliente || ''} onChange={s('respuesta_cliente')}>
                <option value="">Pendiente</option>
                <option value="SI">✅ Aprobado</option>
                <option value="Parcial">⚠ Parcial</option>
                <option value="NO">❌ Rechazado</option>
              </select>
            </Field>
            <Field label="Hora de respuesta">
              <div style={{ ...inp, color: '#64748b' }}>{fmt(form.respuesta_fecha)}</div>
            </Field>
          </div>
          {form.respuesta_cliente && !form.respuesta_fecha && (
            <button onClick={registrarRespuesta} style={{ background: '#10b981', color: '#fff', border: 'none', borderRadius: '6px', padding: '0.4rem 1rem', cursor: 'pointer', fontSize: '0.8rem', marginBottom: '0.5rem' }}>
              ⏰ Registrar hora de respuesta
            </button>
          )}
        </>)}
      </div>

      <Field label="Notas"><input style={inp} value={form.notas || ''} onChange={s('notas')} /></Field>

      <div style={{ display: 'flex', gap: '1.5rem', marginBottom: '1rem' }}>
        <label style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', color: '#e2e8f0', fontSize: '0.85rem', cursor: 'pointer' }}>
          <input type="checkbox" checked={form.lavado || false} onChange={s('lavado')} /> Fue a lavar
        </label>
        <label style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', color: '#e2e8f0', fontSize: '0.85rem', cursor: 'pointer' }}>
          <input type="checkbox" checked={form.terminado_en_dia || false} onChange={s('terminado_en_dia')} /> Terminado en el día
        </label>
      </div>

      <div style={{ display: 'flex', gap: '0.75rem' }}>
        {form.estado !== ESTADOS.FINALIZADO && (
          <button onClick={finalizar} style={{ flex: 1, background: '#22c55e', color: '#fff', border: 'none', borderRadius: '8px', padding: '0.75rem', cursor: 'pointer', fontWeight: 600, fontSize: '0.85rem' }}>
            ✓ Finalizar
          </button>
        )}
        <button onClick={save} style={{ flex: 1, background: '#3b82f6', color: '#fff', border: 'none', borderRadius: '8px', padding: '0.75rem', cursor: 'pointer', fontWeight: 600, fontSize: '0.85rem' }}>
          💾 Guardar
        </button>
      </div>
    </Modal>
  )
}

// ─── ORDER CARD ───────────────────────────────────────────────────────────────
function OrdenCard({ orden, onClick }) {
  const col = ESTADO_COLOR[orden.estado]
  return (
    <div onClick={onClick} style={{ background: '#141824', border: `1px solid ${col}44`, borderLeft: `3px solid ${col}`, borderRadius: '8px', padding: '0.75rem 1rem', cursor: 'pointer', marginBottom: '0.5rem', transition: 'background 0.15s' }}
      onMouseEnter={e => e.currentTarget.style.background = '#1a2035'}
      onMouseLeave={e => e.currentTarget.style.background = '#141824'}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '0.25rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
          <span style={{ color: '#e2e8f0', fontWeight: 700 }}>#{orden.orden}</span>
          <span style={{ background: col + '22', color: col, fontSize: '0.7rem', padding: '2px 8px', borderRadius: '12px', fontWeight: 600 }}>{orden.estado}</span>
          {orden.presupuesto && <span style={{ background: '#f59e0b22', color: '#f59e0b', fontSize: '0.7rem', padding: '2px 8px', borderRadius: '12px' }}>Presup.</span>}
          {orden.lavado && <span style={{ background: '#06b6d422', color: '#06b6d4', fontSize: '0.7rem', padding: '2px 8px', borderRadius: '12px' }}>🫧 Lavado</span>}
        </div>
        <span style={{ color: '#64748b', fontSize: '0.72rem' }}>{fmt(orden.fecha)}</span>
      </div>
      <div style={{ marginTop: '0.4rem', display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
        <span style={{ color: '#94a3b8', fontSize: '0.78rem' }}>👤 {orden.asesor}</span>
        {(orden.mecanicos || []).length > 0 && <span style={{ color: '#94a3b8', fontSize: '0.78rem' }}>🔧 {orden.mecanicos.join(', ')}</span>}
        {orden.servicio !== 'ninguno' && <span style={{ color: '#94a3b8', fontSize: '0.78rem' }}>🛠 Servicio{orden.adicionales ? ` + ${orden.adicionales.slice(0, 25)}${orden.adicionales.length > 25 ? '...' : ''}` : ''}</span>}
        {orden.otros && <span style={{ color: '#94a3b8', fontSize: '0.78rem' }}>📋 {orden.otros.slice(0, 30)}{orden.otros.length > 30 ? '...' : ''}</span>}
      </div>
      {orden.presupuesto && orden.respuesta_cliente && (
        <div style={{ marginTop: '0.3rem' }}>
          <span style={{ fontSize: '0.73rem', color: orden.respuesta_cliente === 'SI' ? '#22c55e' : orden.respuesta_cliente === 'NO' ? '#ef4444' : '#f59e0b' }}>
            {orden.respuesta_cliente === 'SI' ? '✅ Aprobado' : orden.respuesta_cliente === 'NO' ? '❌ Rechazado' : '⚠ Parcial'}
          </span>
        </div>
      )}
      {orden.notas && <div style={{ marginTop: '0.3rem', color: '#475569', fontSize: '0.72rem', fontStyle: 'italic' }}>💬 {orden.notas}</div>}
    </div>
  )
}

// ─── STAT CARD ────────────────────────────────────────────────────────────────
function Stat({ label, value, sub, color = '#3b82f6' }) {
  return (
    <div style={{ background: '#141824', border: '1px solid #2d3448', borderRadius: '10px', padding: '1rem 1.25rem' }}>
      <div style={{ color: '#64748b', fontSize: '0.68rem', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{label}</div>
      <div style={{ color, fontSize: '1.8rem', fontWeight: 700, lineHeight: 1.2, marginTop: '0.2rem' }}>{value}</div>
      {sub && <div style={{ color: '#475569', fontSize: '0.7rem', marginTop: '0.15rem' }}>{sub}</div>}
    </div>
  )
}

// ─── CONTROL PANEL ────────────────────────────────────────────────────────────
function ControlPanel({ orders }) {
  const [periodo, setPeriodo] = useState('month')
  const [historico, setHistorico] = useState(false)
  const [mesHist, setMesHist] = useState(() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}` })

  const filtered = useMemo(() => {
    if (historico) {
      const [y, m] = mesHist.split('-').map(Number)
      return orders.filter(o => { const d = new Date(o.fecha); return d.getFullYear() === y && d.getMonth() === m - 1 })
    }
    const s = startOf(periodo), e = endOf(periodo)
    return orders.filter(o => { const d = new Date(o.fecha); return d >= s && d <= e })
  }, [orders, periodo, historico, mesHist])

  const total = filtered.length
  const finalizados = filtered.filter(o => o.estado === ESTADOS.FINALIZADO).length
  const enDia = filtered.filter(o => o.terminado_en_dia).length
  const lavados = filtered.filter(o => o.lavado).length
  const conPres = filtered.filter(o => o.presupuesto)
  const presAprobados = conPres.filter(o => o.respuesta_cliente === 'SI').length
  const presParcial = conPres.filter(o => o.respuesta_cliente === 'Parcial').length
  const presRechazados = conPres.filter(o => o.respuesta_cliente === 'NO').length

  const byAsesor = ASESORES.map(a => {
    const mine = filtered.filter(o => o.asesor === a)
    const presA = mine.filter(o => o.presupuesto)
    return {
      a, total: mine.length,
      conServ: mine.filter(o => o.servicio === 'servicio').length,
      conAdic: mine.filter(o => o.servicio === 'servicio' && o.adicionales).length,
      presTotal: presA.length,
      aprob: presA.filter(o => o.respuesta_cliente === 'SI').length,
      parcial: presA.filter(o => o.respuesta_cliente === 'Parcial').length,
      rechaz: presA.filter(o => o.respuesta_cliente === 'NO').length,
      enDia: mine.filter(o => o.terminado_en_dia).length,
    }
  })

  return (
    <div>
      <div style={{ display: 'flex', gap: '0.6rem', marginBottom: '1.5rem', flexWrap: 'wrap', alignItems: 'center' }}>
        {[['day', 'Hoy'], ['week', 'Semana'], ['month', 'Mes'], ['year', 'Año']].map(([k, v]) => (
          <button key={k} onClick={() => { setPeriodo(k); setHistorico(false) }} style={{
            padding: '0.4rem 0.9rem', borderRadius: '6px', border: '1px solid',
            borderColor: !historico && periodo === k ? '#3b82f6' : '#2d3448',
            background: !historico && periodo === k ? '#1d4ed8' : '#0f1320',
            color: !historico && periodo === k ? '#fff' : '#64748b',
            cursor: 'pointer', fontSize: '0.8rem'
          }}>{v}</button>
        ))}
        <button onClick={() => setHistorico(h => !h)} style={{
          padding: '0.4rem 0.9rem', borderRadius: '6px', border: `1px solid ${historico ? '#f59e0b' : '#2d3448'}`,
          background: historico ? '#92400e' : '#0f1320', color: historico ? '#fbbf24' : '#64748b', cursor: 'pointer', fontSize: '0.8rem'
        }}>📅 Histórico</button>
        {historico && <input type="month" style={{ ...inp, width: 'auto' }} value={mesHist} onChange={e => setMesHist(e.target.value)} />}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(120px,1fr))', gap: '0.65rem', marginBottom: '1.5rem' }}>
        <Stat label="Total" value={total} color="#e2e8f0" />
        <Stat label="Finalizadas" value={finalizados} color="#22c55e" sub={`${total > 0 ? ((finalizados / total) * 100).toFixed(0) : 0}%`} />
        <Stat label="Term. en día" value={enDia} color="#3b82f6" sub={`${finalizados > 0 ? ((enDia / finalizados) * 100).toFixed(0) : 0}%`} />
        <Stat label="Lavados" value={lavados} color="#06b6d4" />
        <Stat label="Con presup." value={conPres.length} color="#f59e0b" />
        <Stat label="Aprobados" value={presAprobados} color="#22c55e" sub={`${conPres.length > 0 ? ((presAprobados / conPres.length) * 100).toFixed(0) : 0}%`} />
        <Stat label="Parcial" value={presParcial} color="#f59e0b" />
        <Stat label="Rechazados" value={presRechazados} color="#ef4444" />
      </div>

      <h3 style={{ color: '#94a3b8', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: '0.75rem' }}>Control por Asesor</h3>
      <div style={{ overflowX: 'auto', marginBottom: '1.5rem' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.82rem' }}>
          <thead>
            <tr style={{ background: '#0f1320' }}>
              {['Asesor', 'Órdenes', 'Serv. Básicos', 'c/Adicionales', 'Con Pres.', 'Aprobados', 'Parcial', 'Rechazados', '% Éxito'].map(h => (
                <th key={h} style={{ padding: '0.5rem 0.75rem', color: '#64748b', fontWeight: 500, textAlign: h === 'Asesor' ? 'left' : 'center', whiteSpace: 'nowrap' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {byAsesor.map(({ a, total, conServ, conAdic, presTotal, aprob, parcial, rechaz }) => (
              <tr key={a} style={{ borderBottom: '1px solid #1e2535' }}>
                <td style={{ padding: '0.5rem 0.75rem', color: '#e2e8f0', fontWeight: 600 }}>{a}</td>
                <td style={{ padding: '0.5rem 0.75rem', textAlign: 'center', color: '#94a3b8' }}>{total}</td>
                <td style={{ padding: '0.5rem 0.75rem', textAlign: 'center', color: '#94a3b8' }}>{conServ}</td>
                <td style={{ padding: '0.5rem 0.75rem', textAlign: 'center', color: '#94a3b8' }}>{conAdic}</td>
                <td style={{ padding: '0.5rem 0.75rem', textAlign: 'center', color: '#f59e0b' }}>{presTotal}</td>
                <td style={{ padding: '0.5rem 0.75rem', textAlign: 'center', color: '#22c55e' }}>{aprob}</td>
                <td style={{ padding: '0.5rem 0.75rem', textAlign: 'center', color: '#f59e0b' }}>{parcial}</td>
                <td style={{ padding: '0.5rem 0.75rem', textAlign: 'center', color: '#ef4444' }}>{rechaz}</td>
                <td style={{ padding: '0.5rem 0.75rem', textAlign: 'center', color: '#3b82f6' }}>
                  {presTotal > 0 ? `${(((aprob + parcial) / presTotal) * 100).toFixed(0)}%` : '—'}
                </td>
              </tr>
            ))}
            <tr style={{ background: '#0f1320', fontWeight: 700 }}>
              <td style={{ padding: '0.5rem 0.75rem', color: '#e2e8f0' }}>Totales</td>
              <td style={{ padding: '0.5rem 0.75rem', textAlign: 'center', color: '#e2e8f0' }}>{total}</td>
              <td style={{ padding: '0.5rem 0.75rem', textAlign: 'center', color: '#e2e8f0' }}>{byAsesor.reduce((s, x) => s + x.conServ, 0)}</td>
              <td style={{ padding: '0.5rem 0.75rem', textAlign: 'center', color: '#e2e8f0' }}>{byAsesor.reduce((s, x) => s + x.conAdic, 0)}</td>
              <td style={{ padding: '0.5rem 0.75rem', textAlign: 'center', color: '#f59e0b' }}>{conPres.length}</td>
              <td style={{ padding: '0.5rem 0.75rem', textAlign: 'center', color: '#22c55e' }}>{presAprobados}</td>
              <td style={{ padding: '0.5rem 0.75rem', textAlign: 'center', color: '#f59e0b' }}>{presParcial}</td>
              <td style={{ padding: '0.5rem 0.75rem', textAlign: 'center', color: '#ef4444' }}>{presRechazados}</td>
              <td style={{ padding: '0.5rem 0.75rem', textAlign: 'center', color: '#3b82f6' }}>
                {conPres.length > 0 ? `${(((presAprobados + presParcial) / conPres.length) * 100).toFixed(0)}%` : '—'}
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: '0.75rem' }}>
        {[
          { label: 'Aceptados', val: conPres.length ? ((presAprobados / conPres.length) * 100).toFixed(1) : 0, color: '#22c55e' },
          { label: 'Parcial', val: conPres.length ? ((presParcial / conPres.length) * 100).toFixed(1) : 0, color: '#f59e0b' },
          { label: 'No aprobados', val: conPres.length ? ((presRechazados / conPres.length) * 100).toFixed(1) : 0, color: '#ef4444' },
        ].map(({ label, val, color }) => (
          <div key={label} style={{ background: '#141824', border: `1px solid ${color}33`, borderRadius: '10px', padding: '1rem', textAlign: 'center' }}>
            <div style={{ color: '#64748b', fontSize: '0.68rem', textTransform: 'uppercase' }}>{label}</div>
            <div style={{ color, fontSize: '1.8rem', fontWeight: 700 }}>{val}%</div>
            <div style={{ background: '#0f1320', borderRadius: '6px', height: '6px', marginTop: '0.5rem', overflow: 'hidden' }}>
              <div style={{ background: color, width: `${val}%`, height: '100%', transition: 'width 0.5s' }} />
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
export default function App() {
  const { user } = useAuth()
  const { orders, loading, addOrder, saveOrder } = useOrders()
  const { notifs, unread, markRead, markAllRead } = useNotifications(user?.id)

  const [tab, setTab] = useState('ordenes')
  const [filtroEstado, setFiltroEstado] = useState('todos')
  const [filtroAsesor, setFiltroAsesor] = useState('todos')
  const [busqueda, setBusqueda] = useState('')
  const [showNueva, setShowNueva] = useState(false)
  const [editingOrder, setEditingOrder] = useState(null)
  const [showNotifs, setShowNotifs] = useState(false)

  const displayed = useMemo(() => orders.filter(o => {
    if (filtroEstado !== 'todos' && o.estado !== filtroEstado) return false
    if (filtroAsesor !== 'todos' && o.asesor !== filtroAsesor) return false
    if (busqueda && !o.orden.includes(busqueda) && !o.asesor?.toLowerCase().includes(busqueda.toLowerCase())) return false
    return true
  }), [orders, filtroEstado, filtroAsesor, busqueda])

  const counts = useMemo(() => ({
    espera: orders.filter(o => o.estado === ESTADOS.ESPERA).length,
    proceso: orders.filter(o => o.estado === ESTADOS.PROCESO).length,
    final: orders.filter(o => o.estado === ESTADOS.FINALIZADO).length,
  }), [orders])

  const userName = user?.email?.split('@')[0] || 'Usuario'

  return (
    <div style={{ minHeight: '100vh', background: '#0a0e1a', color: '#e2e8f0', fontFamily: "'Segoe UI', system-ui, sans-serif" }}>
      <Toaster position="top-right" toastOptions={{ style: { background: '#1a1f2e', color: '#e2e8f0', border: '1px solid #2d3448' } }} />

      {/* HEADER */}
      <div style={{ background: '#141824', borderBottom: '1px solid #1e2535', padding: '0 1.5rem', position: 'sticky', top: 0, zIndex: 100 }}>
        <div style={{ maxWidth: '1400px', margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: '56px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <span style={{ fontSize: '1.3rem' }}>🔧</span>
            <span style={{ fontWeight: 700, fontSize: '1.05rem' }}>Taller — Gestión de Órdenes</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            {[['ordenes', '📋 Órdenes'], ['control', '📊 Control']].map(([k, v]) => (
              <button key={k} onClick={() => setTab(k)} style={{
                padding: '0.4rem 1rem', borderRadius: '6px', border: 'none',
                background: tab === k ? '#1d4ed8' : 'transparent',
                color: tab === k ? '#fff' : '#64748b', cursor: 'pointer', fontSize: '0.85rem', fontWeight: tab === k ? 600 : 400
              }}>{v}</button>
            ))}
            {/* Notifications bell */}
            <div style={{ position: 'relative' }}>
              <button onClick={() => setShowNotifs(s => !s)} style={{ background: 'none', border: 'none', color: '#94a3b8', cursor: 'pointer', fontSize: '1.2rem', padding: '0.4rem', position: 'relative' }}>
                🔔
                {unread > 0 && (
                  <span style={{ position: 'absolute', top: 2, right: 2, background: '#ef4444', color: '#fff', fontSize: '0.6rem', padding: '1px 4px', borderRadius: '8px', lineHeight: 1.4 }}>{unread}</span>
                )}
              </button>
              {showNotifs && <NotificationsPanel notifs={notifs} unread={unread} onMarkRead={markRead} onMarkAllRead={markAllRead} onClose={() => setShowNotifs(false)} />}
            </div>
            <span style={{ color: '#475569', fontSize: '0.8rem', marginLeft: '0.5rem' }}>{userName}</span>
            <button onClick={signOut} style={{ background: 'none', border: '1px solid #2d3448', color: '#64748b', cursor: 'pointer', borderRadius: '6px', padding: '0.35rem 0.75rem', fontSize: '0.75rem' }}>Salir</button>
          </div>
        </div>
      </div>

      <div style={{ maxWidth: '1400px', margin: '0 auto', padding: '1.5rem' }}>
        {loading ? (
          <div style={{ textAlign: 'center', color: '#475569', padding: '4rem' }}>Cargando órdenes...</div>
        ) : tab === 'ordenes' ? (
          <>
            <div style={{ display: 'flex', gap: '0.75rem', marginBottom: '1.25rem', flexWrap: 'wrap', alignItems: 'center' }}>
              {[{ label: 'A la espera', count: counts.espera, color: '#e8a838' }, { label: 'En proceso', count: counts.proceso, color: '#3b82f6' }, { label: 'Finalizadas', count: counts.final, color: '#22c55e' }].map(({ label, count, color }) => (
                <div key={label} style={{ background: `${color}18`, border: `1px solid ${color}44`, borderRadius: '8px', padding: '0.5rem 1.25rem', display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
                  <span style={{ color, fontWeight: 700, fontSize: '1.1rem' }}>{count}</span>
                  <span style={{ color: `${color}cc`, fontSize: '0.78rem' }}>{label}</span>
                </div>
              ))}
              <button onClick={() => setShowNueva(true)} style={{ marginLeft: 'auto', background: '#1d4ed8', color: '#fff', border: 'none', borderRadius: '8px', padding: '0.5rem 1.25rem', cursor: 'pointer', fontWeight: 600, fontSize: '0.85rem' }}>
                ➕ Nueva Orden
              </button>
            </div>

            <div style={{ display: 'flex', gap: '0.75rem', marginBottom: '1.25rem', flexWrap: 'wrap' }}>
              <input style={{ ...inp, width: '200px' }} placeholder="🔍 Buscar número u asesor..." value={busqueda} onChange={e => setBusqueda(e.target.value)} />
              <select style={{ ...inp, width: 'auto' }} value={filtroEstado} onChange={e => setFiltroEstado(e.target.value)}>
                <option value="todos">Todos los estados</option>
                {Object.values(ESTADOS).map(e => <option key={e} value={e}>{e}</option>)}
              </select>
              <select style={{ ...inp, width: 'auto' }} value={filtroAsesor} onChange={e => setFiltroAsesor(e.target.value)}>
                <option value="todos">Todos los asesores</option>
                {ASESORES.map(a => <option key={a} value={a}>{a}</option>)}
              </select>
            </div>

            <div style={{ columns: '2', columnGap: '1rem' }}>
              {displayed.map(o => (
                <div key={o.id} style={{ breakInside: 'avoid' }}>
                  <OrdenCard orden={o} onClick={() => setEditingOrder(o)} />
                </div>
              ))}
            </div>
            {displayed.length === 0 && (
              <div style={{ textAlign: 'center', color: '#475569', padding: '3rem', background: '#141824', borderRadius: '10px' }}>
                No hay órdenes con los filtros seleccionados
              </div>
            )}
          </>
        ) : (
          <ControlPanel orders={orders} />
        )}
      </div>

      {showNueva && <NuevaOrdenModal onClose={() => setShowNueva(false)} onSave={addOrder} />}
      {editingOrder && <EditarOrdenModal orden={editingOrder} onClose={() => setEditingOrder(null)} onSave={saveOrder} />}
    </div>
  )
}

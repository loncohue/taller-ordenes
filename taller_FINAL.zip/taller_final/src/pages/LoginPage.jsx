import { useState } from 'react'
import { signIn } from '../lib/supabase'
import toast from 'react-hot-toast'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)

  const inp = {
    background: '#0f1320', border: '1px solid #2d3448', borderRadius: '8px',
    color: '#e2e8f0', padding: '0.75rem 1rem', width: '100%',
    fontSize: '0.95rem', outline: 'none', boxSizing: 'border-box',
  }

  const handleLogin = async (e) => {
    e.preventDefault()
    setLoading(true)
    const { error } = await signIn(email, password)
    if (error) {
      toast.error('Email o contraseña incorrectos')
    }
    setLoading(false)
  }

  return (
    <div style={{
      minHeight: '100vh', background: '#0a0e1a', display: 'flex',
      alignItems: 'center', justifyContent: 'center', padding: '1rem'
    }}>
      <div style={{
        background: '#141824', border: '1px solid #2d3448', borderRadius: '16px',
        padding: '2.5rem', width: '100%', maxWidth: '400px',
        boxShadow: '0 25px 60px rgba(0,0,0,0.5)'
      }}>
        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <div style={{ fontSize: '3rem', marginBottom: '0.5rem' }}>🔧</div>
          <h1 style={{ color: '#e2e8f0', margin: 0, fontSize: '1.4rem', fontWeight: 700 }}>Taller</h1>
          <p style={{ color: '#64748b', margin: '0.25rem 0 0', fontSize: '0.85rem' }}>Gestión de Órdenes</p>
        </div>

        <form onSubmit={handleLogin}>
          <div style={{ marginBottom: '1rem' }}>
            <label style={{ display: 'block', color: '#94a3b8', fontSize: '0.75rem', marginBottom: '6px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
              Email
            </label>
            <input style={inp} type="email" value={email} onChange={e => setEmail(e.target.value)}
              placeholder="tu@email.com" required autoComplete="email" />
          </div>

          <div style={{ marginBottom: '1.5rem' }}>
            <label style={{ display: 'block', color: '#94a3b8', fontSize: '0.75rem', marginBottom: '6px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
              Contraseña
            </label>
            <input style={inp} type="password" value={password} onChange={e => setPassword(e.target.value)}
              placeholder="••••••••" required autoComplete="current-password" />
          </div>

          <button type="submit" disabled={loading} style={{
            width: '100%', background: loading ? '#1e3a8a' : '#1d4ed8',
            color: '#fff', border: 'none', borderRadius: '8px',
            padding: '0.85rem', cursor: loading ? 'not-allowed' : 'pointer',
            fontWeight: 700, fontSize: '0.95rem', transition: 'background 0.2s'
          }}>
            {loading ? 'Ingresando...' : 'Ingresar'}
          </button>
        </form>

        <p style={{ color: '#475569', fontSize: '0.75rem', textAlign: 'center', marginTop: '1.5rem', marginBottom: 0 }}>
          Para obtener acceso, contactá al administrador del sistema.
        </p>
      </div>
    </div>
  )
}

import { useEffect, useRef } from 'react'
import { formatDistanceToNow } from 'date-fns'
import { es } from 'date-fns/locale'

export default function NotificationsPanel({ notifs, unread, onMarkRead, onMarkAllRead, onClose }) {
  const ref = useRef()

  useEffect(() => {
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) onClose() }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [onClose])

  return (
    <div ref={ref} style={{
      position: 'absolute', top: '48px', right: 0, width: '340px',
      background: '#1a1f2e', border: '1px solid #2d3448', borderRadius: '12px',
      boxShadow: '0 20px 50px rgba(0,0,0,0.5)', zIndex: 999, overflow: 'hidden'
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '1rem 1.25rem', borderBottom: '1px solid #2d3448' }}>
        <span style={{ color: '#e2e8f0', fontWeight: 600, fontSize: '0.9rem' }}>
          🔔 Notificaciones {unread > 0 && <span style={{ background: '#ef4444', color: '#fff', fontSize: '0.7rem', padding: '2px 6px', borderRadius: '10px', marginLeft: '6px' }}>{unread}</span>}
        </span>
        {unread > 0 && (
          <button onClick={onMarkAllRead} style={{ background: 'none', border: 'none', color: '#3b82f6', cursor: 'pointer', fontSize: '0.75rem' }}>
            Marcar todas leídas
          </button>
        )}
      </div>

      <div style={{ maxHeight: '360px', overflowY: 'auto' }}>
        {notifs.length === 0 ? (
          <div style={{ padding: '2rem', textAlign: 'center', color: '#475569', fontSize: '0.85rem' }}>
            Sin notificaciones
          </div>
        ) : notifs.map(n => (
          <div key={n.id} onClick={() => onMarkRead(n.id)} style={{
            padding: '0.875rem 1.25rem', borderBottom: '1px solid #1e2535',
            background: n.leida ? 'transparent' : '#1d4ed820',
            cursor: 'pointer', transition: 'background 0.15s'
          }}
            onMouseEnter={e => e.currentTarget.style.background = '#1e2535'}
            onMouseLeave={e => e.currentTarget.style.background = n.leida ? 'transparent' : '#1d4ed820'}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '0.5rem' }}>
              <span style={{ color: n.leida ? '#94a3b8' : '#e2e8f0', fontSize: '0.83rem', lineHeight: 1.4 }}>{n.mensaje}</span>
              {!n.leida && <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: '#3b82f6', flexShrink: 0, marginTop: '4px' }} />}
            </div>
            <div style={{ color: '#475569', fontSize: '0.7rem', marginTop: '4px' }}>
              {formatDistanceToNow(new Date(n.created_at), { addSuffix: true, locale: es })}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

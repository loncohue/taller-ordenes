import { useEffect, useState, useCallback } from 'react'
import { fetchNotifications, markNotifRead, markAllNotifsRead, subscribeToNotifications } from '../lib/supabase'
import toast from 'react-hot-toast'

export function useNotifications(userId) {
  const [notifs, setNotifs] = useState([])
  const unread = notifs.filter(n => !n.leida).length

  const load = useCallback(async () => {
    if (!userId) return
    try {
      const data = await fetchNotifications(userId)
      setNotifs(data)
    } catch (e) { /* silent */ }
  }, [userId])

  useEffect(() => {
    load()
    if (!userId) return
    const channel = subscribeToNotifications(userId, (payload) => {
      const n = payload.new
      setNotifs(prev => [n, ...prev])
      toast(n.mensaje, { icon: '🔔', duration: 5000 })
    })
    return () => channel.unsubscribe()
  }, [userId, load])

  const markRead = useCallback(async (id) => {
    await markNotifRead(id)
    setNotifs(prev => prev.map(n => n.id === id ? { ...n, leida: true } : n))
  }, [])

  const markAllRead = useCallback(async () => {
    await markAllNotifsRead(userId)
    setNotifs(prev => prev.map(n => ({ ...n, leida: true })))
  }, [userId])

  return { notifs, unread, markRead, markAllRead }
}

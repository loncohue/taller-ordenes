import { useEffect, useState, useCallback } from 'react'
import { fetchOrders, insertOrder, updateOrder, subscribeToOrders } from '../lib/supabase'
import toast from 'react-hot-toast'

export function useOrders() {
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    try {
      const data = await fetchOrders()
      setOrders(data)
    } catch (e) {
      toast.error('Error cargando órdenes')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    load()
    const channel = subscribeToOrders((payload) => {
      const { eventType, new: newRow, old: oldRow } = payload
      if (eventType === 'INSERT') {
        setOrders(prev => [newRow, ...prev])
        toast(`📋 Nueva orden #${newRow.orden} ingresada`, { icon: '🆕' })
      } else if (eventType === 'UPDATE') {
        setOrders(prev => prev.map(o => o.id === newRow.id ? newRow : o))
        // Notify state changes
        if (oldRow.estado !== newRow.estado) {
          const icons = { 'En proceso': '🔧', 'Finalizado': '✅', 'A la espera': '⏳' }
          toast(`${icons[newRow.estado] || '🔄'} Orden #${newRow.orden} → ${newRow.estado}`, { duration: 4000 })
        }
      } else if (eventType === 'DELETE') {
        setOrders(prev => prev.filter(o => o.id !== oldRow.id))
      }
    })
    return () => channel.unsubscribe()
  }, [load])

  const addOrder = useCallback(async (orderData) => {
    const toInsert = {
      ...orderData,
      fecha: new Date().toISOString(),
      estado: 'A la espera',
      mecanicos: [],
      presupuesto: false,
      presupuesto_tipo: '',
      presupuesto_detalle: '',
      respuesta_cliente: '',
      respuesta_fecha: null,
      lavado: false,
      terminado_en_dia: false,
      finalizado_fecha: null,
      notas: '',
    }
    try {
      await insertOrder(toInsert)
      toast.success(`Orden #${orderData.orden} creada`)
    } catch (e) {
      toast.error('Error al crear la orden')
      throw e
    }
  }, [])

  const saveOrder = useCallback(async (updated) => {
    try {
      await updateOrder(updated.id, updated)
      toast.success('Orden guardada')
    } catch (e) {
      toast.error('Error al guardar')
      throw e
    }
  }, [])

  return { orders, loading, addOrder, saveOrder, reload: load }
}

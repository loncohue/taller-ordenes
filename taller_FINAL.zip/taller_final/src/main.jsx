import React from 'react'
import ReactDOM from 'react-dom/client'
import { AuthProvider, useAuth } from './hooks/useAuth'
import App from './pages/App'
import LoginPage from './pages/LoginPage'

function Root() {
  const { user, loading } = useAuth()
  if (loading) return (
    <div style={{ minHeight: '100vh', background: '#0a0e1a', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ color: '#475569', fontSize: '1rem' }}>Cargando...</div>
    </div>
  )
  return user ? <App /> : <LoginPage />
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <AuthProvider>
      <Root />
    </AuthProvider>
  </React.StrictMode>
)
